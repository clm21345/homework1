import struct

input_file = 'random_numbers_sorted.bin'  
output_file = 'random_numbers_sorted.txt' 

INT_SIZE = 8 
FORMAT = 'q' 

with open(input_file, 'rb') as f_in, open(output_file, 'w') as f_out:
    while True:
        data = f_in.read(INT_SIZE)
        if not data:
            break
        number = struct.unpack(FORMAT, data)[0]
        f_out.write(f"{number}\n")

print(f"Converted {input_file} to {output_file}")