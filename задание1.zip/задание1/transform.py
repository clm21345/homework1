import struct

with open('random_numbers.txt', 'r') as f:
    numbers = [int(line.strip()) for line in f]

with open('random_numbers.bin', 'wb') as f:
    for num in numbers:
        f.write(struct.pack('q', num))